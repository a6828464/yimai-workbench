#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import requests

PROFILE_ENV = Path('${HERMES_PROFILE_DIR}/.env')
BASE_URL = 'https://cloud.keepyoga.com'
BRAND_ID = '108193'
VERSION = '10.1.3'
STORES = {'绿地店': '1', '东部店': '4250'}


def load_env() -> None:
    if not PROFILE_ENV.exists():
        return
    for line in PROFILE_ENV.read_text(errors='ignore').splitlines():
        if not line or line.lstrip().startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def post(session: requests.Session, base: str, path: str, body: dict[str, Any], timeout: int = 45) -> dict[str, Any]:
    r = session.post(base + path, data=body, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    if data.get('errno') not in (0, '0', None):
        raise RuntimeError(f'{path} failed: {data}')
    return data


def login() -> tuple[requests.Session, str]:
    load_env()
    phone = os.environ.get('KEEPYOGA_PHONE') or os.environ.get('YIMAI_KEEPYOGA_PHONE')
    password = os.environ.get('KEEPYOGA_PASSWORD') or os.environ.get('YIMAI_KEEPYOGA_PASSWORD')
    if not phone or not password:
        raise RuntimeError('missing KEEPYOGA_PHONE/KEEPYOGA_PASSWORD in profile .env')
    session = requests.Session()
    pwd = hashlib.md5(password.encode('utf-8')).hexdigest()
    data = post(session, BASE_URL, '/passport/api/login', {'phone': phone, 'pwd': pwd, 'keep': 1, 'brand_id': '', 'venue_id': ''}, 30)
    return session, data['data']['access_token']


def common(token: str, venue_id: str) -> dict[str, Any]:
    return {'access_token': token, 'brand_id': BRAND_ID, 'venue_id': venue_id, 'version': VERSION, 'os': 'pc'}


def data_list(data: dict[str, Any]) -> list[dict[str, Any]]:
    obj = data.get('data')
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for key in ('list', 'data', 'rows', 'items', 'members', 'visitors', 'mcards', 'contracts', 'course_schedule', 'reservations'):
            val = obj.get(key)
            if isinstance(val, list):
                return val
    return []


def total_count(data: dict[str, Any], rows: list[dict[str, Any]]) -> int:
    obj = data.get('data')
    if isinstance(obj, dict):
        for key in ('total', 'count', 'recordsTotal', 'total_count'):
            val = obj.get(key)
            if val not in (None, ''):
                try:
                    return int(float(val))
                except Exception:
                    pass
        fenye = obj.get('fenye')
        if isinstance(fenye, dict):
            for key in ('record_count', 'total', 'count', 'total_count'):
                val = fenye.get(key)
                if val not in (None, ''):
                    try:
                        return int(float(val))
                    except Exception:
                        pass
    return len(rows)


def tail(value: Any, n: int = 4) -> str:
    digits = re.sub(r'\D', '', str(value or ''))
    return digits[-n:] if digits else ''


def safe_text(value: Any) -> str:
    text = str(value or '').strip()
    text = re.sub(r'1\d{10}', lambda m: '******' + m.group(0)[-4:], text)
    text = re.sub(r'\b\d{12,}\b', lambda m: '***' + m.group(0)[-4:], text)
    return text[:500]


def first(row: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in row and row.get(key) not in (None, ''):
            return row.get(key)
    for k, v in row.items():
        if any(key in str(k) for key in keys) and v not in (None, ''):
            return v
    return ''


def search_members(session: requests.Session, token: str, venue_id: str, query: str) -> tuple[str, list[dict[str, Any]]]:
    body = {**common(token, venue_id), 'page_index': 1, 'page_size': 20, 'cond': query, 'consultant_id': -1}
    members = data_list(post(session, BASE_URL, '/member/api/getmembersbycondwithpager', body))
    if members:
        return 'member', members
    visitors = data_list(post(session, BASE_URL, '/member/api/getvisitors', body))
    if visitors:
        return 'visitor', visitors
    card_body = {**common(token, venue_id), 'page_index': 1, 'page_size': 20, 'cond': query, 'search': query, 'consultant_id': -1}
    cards = data_list(post(session, BASE_URL, '/mcard/api/getmcardsbycond', card_body))
    return 'mcard', cards


def member_id(row: dict[str, Any]) -> str:
    for key in ('member_id', 'id', 'home_member_id'):
        if row.get(key):
            return str(row[key])
    return ''


def get_detail(session: requests.Session, token: str, venue_id: str, mid: str) -> dict[str, Any]:
    if not mid:
        return {}
    data = post(session, BASE_URL, '/member/api/getmemberdetail', {**common(token, venue_id), 'member_id': mid, 'home_member_id': '0'})
    return data.get('data') if isinstance(data.get('data'), dict) else {}


def get_cards(session: requests.Session, token: str, venue_id: str, mid: str, query: str) -> list[dict[str, Any]]:
    if mid:
        try:
            return data_list(post(session, BASE_URL, '/mcard/api/getmcardbymemberid', {**common(token, venue_id), 'member_id': mid, 'home_member_id': '0'}))
        except Exception:
            pass
    return data_list(post(session, BASE_URL, '/mcard/api/getmcardsbycond', {**common(token, venue_id), 'page_index': 1, 'page_size': 50, 'cond': query, 'search': query, 'consultant_id': -1}))


def get_records(session: requests.Session, token: str, venue_id: str, query: str) -> list[dict[str, Any]]:
    start = (dt.date.today() - dt.timedelta(days=730)).strftime('%Y%m%d')
    end = (dt.date.today() + dt.timedelta(days=30)).strftime('%Y%m%d')
    rows: list[dict[str, Any]] = []
    for path in ('/course/api/queryreversionleague', '/course/api/queryreversionprivate'):
        body = {**common(token, venue_id), 'page_index': 1, 'page_size': 200, 's_date': start, 'e_date': end, 'status_code': 'all', 'course_id': 0, 'coach_id': 0, 'm_card_id': 0, 'search': query}
        if 'league' in path:
            body['course_type'] = 0
        try:
            got = data_list(post(session, BASE_URL, path, body))
            for item in got:
                item['_record_type'] = '团课/小班' if 'league' in path else '私教'
            rows.extend(got)
        except Exception as exc:
            rows.append({'_record_type': 'error', 'error': str(exc), 'path': path})
    return rows


def parse_date(value: Any) -> dt.date | None:
    text = str(value or '')[:10].replace('/', '-').replace('.', '-')
    for fmt in ('%Y-%m-%d', '%Y%m%d'):
        try:
            return dt.datetime.strptime(text, fmt).date()
        except Exception:
            pass
    return None


def summarize_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    real = [r for r in records if r.get('_record_type') != 'error']
    teachers: Counter[str] = Counter()
    weekdays: Counter[str] = Counter()
    periods: Counter[str] = Counter()
    signed = cancelled = 0
    last_date: dt.date | None = None
    for r in real:
        teachers.update([safe_text(first(r, 'coach_name', 'coach', 'teacher_name', '老师')) or '未标记'])
        text = json.dumps(r, ensure_ascii=False)
        if any(w in text for w in ('取消', '爽约', '未到')):
            cancelled += 1
        if any(w in text for w in ('签到', '已上课', '完成')):
            signed += 1
        d = parse_date(first(r, 'date', 'course_date', 'start_time', '预约时间', '上课时间'))
        if d:
            last_date = max(last_date, d) if last_date else d
            weekdays.update(['周' + '一二三四五六日'[d.weekday()]])
        time_text = str(first(r, 'start', 'start_time', 'time', '预约时间', '上课时间'))
        m = re.search(r'(\d{1,2}):', time_text)
        if m:
            h = int(m.group(1))
            periods.update(['上午' if h < 12 else '下午' if h < 18 else '晚上'])
    return {'total': len(real), 'signed': signed, 'cancelled': cancelled, 'cancel_rate': round(cancelled / len(real), 3) if real else 0, 'top_teachers': teachers.most_common(5), 'top_weekdays': weekdays.most_common(3), 'top_periods': periods.most_common(3), 'last_date': str(last_date) if last_date else ''}


def card_summary(cards: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for c in cards[:20]:
        out.append({'card_name': safe_text(first(c, 'card_title', 'card_name', 'name', '卡名称')), 'status': safe_text(first(c, 'mcard_status', 'status', '卡状态')), 'remain': safe_text(first(c, 'residue_amount', 'remain', 'balance', '余额', '剩余')), 'deadline': safe_text(first(c, 'deadline', 'expire_time', '有效期')), 'deal_price': safe_text(first(c, 'deal_price', 'price', '成交', '收费')), 'assets': safe_text(first(c, 'remaining_assets', '剩余资产')), 'card_no_tail': tail(first(c, 'card_no', '卡号'))})
    return out


def analyze(args: argparse.Namespace) -> dict[str, Any]:
    session, token = login()
    venue_id = STORES[args.venue]
    status, matches = search_members(session, token, venue_id, args.query)
    if not matches:
        return {'ok': True, 'match_status': 'not_found', 'venue': args.venue, 'query': args.query}
    chosen = matches[0]
    mid = member_id(chosen)
    detail = get_detail(session, token, venue_id, mid)
    cards = get_cards(session, token, venue_id, mid, args.query)
    records = get_records(session, token, venue_id, args.query)
    rec = summarize_records(records)
    profile = {**chosen, **detail}
    result = {'ok': True, 'match_status': status, 'venue': args.venue, 'query': args.query, 'selected_member_id': mid, 'name': safe_text(first(profile, 'name', 'member_name', '姓名')), 'phone_tail': tail(first(profile, 'phone', 'mobile', '手机号')), 'source': safe_text(first(profile, 'source_title', 'source', '来源')), 'consultant': safe_text(first(profile, 'consultant_name', 'consultant', '顾问')), 'coach': safe_text(first(profile, 'coach_name', 'coach', '教练')), 'created_at': safe_text(first(profile, 'create_time', 'created_at', '录入日期')), 'total_consume': safe_text(first(profile, 'total_consume', 'consume_total', '累计消耗')), 'remaining_assets': safe_text(first(profile, 'remaining_assets', 'surplus_asset', '剩余资产')), 'cards': card_summary(cards), 'records': rec, 'record_errors': [r for r in records if r.get('_record_type') == 'error']}
    return result


def counts() -> dict[str, Any]:
    session, token = login()
    out = {'ok': True, 'stores': {}}
    for store, venue_id in STORES.items():
        c: dict[str, Any] = {}
        for key, path, body in [
            ('members', '/member/api/getmembersbycondwithpager', {'page_index': 1, 'page_size': 1, 'cond': '', 'consultant_id': -1}),
            ('visitors', '/member/api/getvisitors', {'page': '1', 'page_size': '1', 'cond': '', 'source_id': '-1', 'activity_id': '-1', 'activity_code': '', 'consultant_id': '-1', 'begin_time': '', 'end_time': '', 'revisit_status': '', 'trainer_id': '-1'}),
            ('mcards', '/mcard/api/getmcardsbycond', {'page_index': 1, 'page_size': 1, 'cond': '', 'search': '', 'consultant_id': -1}),
            ('contracts', '/venue/api/getallcontractlist', {'page_index': '1', 'page_size': '1', 'contract_status': '0', 'contract_name': '', 'initiator_emp_name': '', 'venue_signatory_emp_name': '', 'customer_signatory_search': '', 'initiator_start_date': '', 'initiator_end_date': ''}),
        ]:
            try:
                data = post(session, BASE_URL, path, {**common(token, venue_id), **body})
                rows = data_list(data)
                c[key] = total_count(data, rows)
            except Exception as exc:
                c[key] = {'error': str(exc)}
        out['stores'][store] = c
    return out


def venues() -> dict[str, Any]:
    session, token = login()
    data = post(session, BASE_URL, '/passport/api/getvenues', {'access_token': token, 'brand_id': BRAND_ID, 'version': VERSION, 'os': 'pc'})
    return {'ok': True, 'known': STORES, 'raw_count': len(data_list(data)), 'venues': data_list(data)}


def main() -> None:
    parser = argparse.ArgumentParser(description='Yi Mai KeepYoga read-only realtime query')
    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('venues')
    sub.add_parser('counts')
    p = sub.add_parser('member-analyze')
    p.add_argument('--venue', choices=sorted(STORES), required=True)
    p.add_argument('--query', required=True)
    args = parser.parse_args()
    try:
        if args.cmd == 'venues':
            result = venues()
        elif args.cmd == 'counts':
            result = counts()
        else:
            result = analyze(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}, ensure_ascii=False, indent=2))
        raise


if __name__ == '__main__':
    main()
