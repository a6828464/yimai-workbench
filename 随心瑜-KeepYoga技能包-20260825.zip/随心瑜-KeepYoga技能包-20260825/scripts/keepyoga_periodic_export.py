#!/usr/bin/env python3
"""Export Yi Mai KeepYoga P0/P1 data into the business wiki.

This script logs into cloud.keepyoga.com, exports verified weekly/monthly data,
downloads files immediately, converts .xls to .xlsx, and prints a JSON summary.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests

ROOT = Path("${YIMAI_BIZ_WIKI}")
RAW = ROOT / "raw/booking-data/定期导出"
PROFILE_ENV = Path("${HERMES_PROFILE_DIR}/.env")
if PROFILE_ENV.exists():
    for line in PROFILE_ENV.read_text().splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
BASE_URL = "https://cloud.keepyoga.com"
DOWNLOAD_URL = "https://importandexport.keepyoga.com"
BRAND_ID = "108193"
VERSION = "10.1.3"
PHONE = os.environ.get("KEEPYOGA_PHONE", "")
PASSWORD = os.environ.get("KEEPYOGA_PASSWORD", "")
STORES = {"绿地店": "1", "东部店": "4250"}

MEMBER_COLUMNS = [
    {"title": "姓名", "code": "name", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "性别", "code": "sex", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "手机号", "code": "phone", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "当前积分", "code": "points", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "会籍顾问", "code": "consultant_name", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "活动名称", "code": "activity_name", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "渠道来源", "code": "source_title", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "录入日期", "code": "create_time", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "会员生日", "code": "birthday", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "证件号", "code": "credential_no", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "备注", "code": "notes", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "详细小区名称", "code": "housing_estate", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "职业类型", "code": "occupation_type", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "行为动态", "code": "notes_behavior", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "婚姻情况", "code": "marriage", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "孕产情况", "code": "pregnancy", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "性格特征", "code": "personality_traits", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "收入情况", "code": "income_situation", "is_default": "0", "is_not_editable": "0", "flag": 0},
]

MCARD_COLUMNS = [
    {"title": "姓名", "code": "name", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "性别", "code": "sex", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "手机号", "code": "phone", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "会籍顾问", "code": "consultant_name", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "入会时间", "code": "m_create_time", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "出生日期", "code": "birthday", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "证件类型", "code": "credential_type_title", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "证件号", "code": "credential_no", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "渠道来源", "code": "source_title", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "详细小区名称", "code": "housing_estate", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "职业类型", "code": "occupation_type", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "行为动态", "code": "notes_behavior", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "婚姻情况", "code": "marriage", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "孕产情况", "code": "pregnancy", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "卡类型", "code": "card_type_title", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "卡名称", "code": "card_title", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "卡号", "code": "card_no", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "卡状态", "code": "mcard_status", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "发卡日期", "code": "issue_time", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "开卡日期", "code": "activate_time", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "有效期至", "code": "deadline", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "余额", "code": "residue_amount", "is_default": "1", "is_not_editable": "1", "flag": 1},
    {"title": "收费金额", "code": "deal_price", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "会员备注", "code": "notes", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "地址", "code": "address", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "会员卡备注", "code": "mcard_notes", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "初始余额", "code": "initial_amount", "is_default": "0", "is_not_editable": "0", "flag": 0},
    {"title": "剩余资产折算", "code": "remaining_assets", "is_default": "1", "is_not_editable": "1", "flag": 1},
]


P0_ITEMS = [
    ("会员基础表", BASE_URL, "/member/api/exportmemorvisitor", lambda start, end: {
        "type": 1,
        "activity_code": -1,
        "activity_id": -1,
        "source_id": -1,
        "consultant_id": -1,
        "birthday_begin": "",
        "birthday_end": "",
        "start_time": "",
        "end_time": "",
        "columns": json.dumps(MEMBER_COLUMNS, ensure_ascii=False),
    }, "全量"),
    ("会员卡表", BASE_URL, "/member/api/exportmm", lambda start, end: {
        "activity_code": -1,
        "activity_id": -1,
        "mcard_type": 0,
        "card_type": 0,
        "card_id": 0,
        "card_status": 0,
        "start_time": "",
        "end_time": "",
        "columns": json.dumps(MCARD_COLUMNS, ensure_ascii=False),
    }, "全量"),
    ("团课预约记录", DOWNLOAD_URL, "/course/api/exportqueryreversionleague", lambda start, end: {
        "s_date": start.strftime("%Y%m%d"),
        "e_date": end.strftime("%Y%m%d"),
        "status_code": "all",
        "course_type": 0,
        "course_id": 0,
        "coach_id": 0,
        "m_card_id": 0,
        "search": "",
    }, "range"),
    ("私教预约记录", DOWNLOAD_URL, "/course/api/exportqueryreversionprivate", lambda start, end: {
        "s_date": start.strftime("%Y%m%d"),
        "e_date": end.strftime("%Y%m%d"),
        "status_code": "all",
        "course_id": 0,
        "coach_id": 0,
        "m_card_id": 0,
        "search": "",
    }, "range"),
    ("刷卡扣费记录", DOWNLOAD_URL, "/course/api/exportpaybycard", lambda start, end: {
        "s_date": start.strftime("%Y%m%d"),
        "e_date": end.strftime("%Y%m%d"),
        "course_type": 0,
        "course_id": 0,
        "search": "",
    }, "range"),
    ("变更记录", BASE_URL, "/mcard/api/exportmcardlogs", lambda start, end: {
        "begin_time": start.strftime("%Y-%m-%d"),
        "end_time": end.strftime("%Y-%m-%d"),
        "operation_type": 0,
        "cond": "",
    }, "range"),
]

P1_DIRECT_ITEMS = [
    ("售卡统计", BASE_URL, "/mcard/api/exportmcardstat", lambda start, end: {
        "type": 1,
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d"),
        "consultant_id": 0,
        "flag": 1,
        "buy_source": -1,
        "is_taste": 2,
        "payment_id": 0,
        "search": "",
        "operator_name": "",
    }),
    ("上课耗卡明细", DOWNLOAD_URL, "/mcard/api/exportconsumecarddetailstatis", lambda start, end: {
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d"),
        "card_type": 0,
        "card_id": 0,
        "card_num": "",
        "search": "",
        "member_id": 0,
        "home_member_id": 0,
    }),
    ("课时费统计", BASE_URL, "/course/api/exportcoursesummaryrecordstat", lambda start, end: {
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d"),
        "coach_id": 0,
        "course_type": 0,
        "page_index": 1,
        "page_size": 5000,
    }),
    ("收款统计", BASE_URL, "/sale/api/exportreceivablesstatistics", lambda start, end: {
        "start_time": start.strftime("%Y-%m-%d"),
        "end_time": end.strftime("%Y-%m-%d"),
        "consultant_id": 0,
        "order_type": 0,
        "settlement_status": 0,
    }),
]

P1_CENTER_ITEMS = [
    ("收入汇总", 18),
    ("耗卡汇总", 19),
    ("资产负债表", 20),
]
P1_CENTER_NAME_TO_TYPE = {name: str(select_type) for name, select_type in P1_CENTER_ITEMS}


def log(message: str) -> None:
    print(message, file=sys.stderr)


def post_json(session: requests.Session, base: str, path: str, body: dict[str, Any], timeout: int = 90) -> dict[str, Any]:
    response = session.post(base + path, data=body, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    if data.get("errno") not in (0, "0", None):
        raise RuntimeError(f"{path} failed: {data}")
    return data


def login() -> tuple[requests.Session, str]:
    session = requests.Session()
    password_md5 = hashlib.md5(PASSWORD.encode("utf-8")).hexdigest()
    data = post_json(
        session,
        BASE_URL,
        "/passport/api/login",
        {"phone": PHONE, "pwd": password_md5, "keep": 1, "brand_id": "", "venue_id": ""},
        timeout=30,
    )
    token = data["data"]["access_token"]
    return session, token


def common(token: str, venue_id: str) -> dict[str, Any]:
    return {"access_token": token, "brand_id": BRAND_ID, "venue_id": venue_id, "version": VERSION, "os": "pc"}


def safe_ext_from_url(url: str, fallback: str = ".xls") -> str:
    suffix = Path(urlparse(url).path).suffix.lower()
    return suffix if suffix in {".xls", ".xlsx", ".csv"} else fallback


def download_file(session: requests.Session, url: str, path: Path) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    response = session.get(url, timeout=120)
    response.raise_for_status()
    path.write_bytes(response.content)
    return path.stat().st_size


def export_direct(session: requests.Session, token: str, store: str, venue_id: str, item: tuple, start: dt.date, end: dt.date, out_dir: Path, export_date: dt.date) -> dict[str, Any]:
    name, base, path, body_fn, scope = item
    body = {**common(token, venue_id), **body_fn(start, end)}
    data = post_json(session, base, path, body)
    file_url = (data.get("data") or {}).get("url")
    if not file_url:
        raise RuntimeError(f"{store} {name} no url: {data}")
    count = (data.get("data") or {}).get("count")
    period = "全量" if scope == "全量" else f"{start:%Y-%m-%d}至{end:%Y-%m-%d}"
    dest = out_dir / f"{store}-{name}-{period}-{export_date:%Y-%m-%d}{safe_ext_from_url(file_url)}"
    size = download_file(session, file_url, dest)
    return {"store": store, "name": name, "count": count, "path": str(dest), "size": size, "url": file_url}


def submit_center_export(session: requests.Session, token: str, venue_id: str, select_type: int, month: str) -> dict[str, Any]:
    if select_type in (18, 19):
        params = {"select_type": select_type, "data_type": "monthly", "start_time": month, "end_time": month}
    else:
        params = {"customer_type": 0, "sort_type": 1, "search": "", "select_type": select_type}
    body = {**common(token, venue_id), "export_params": json.dumps(params, ensure_ascii=False)}
    return post_json(session, BASE_URL, "/venue/api/financialstatementscommonexport", body)


def center_records(session: requests.Session, token: str, venue_id: str) -> list[dict[str, Any]]:
    data = post_json(session, BASE_URL, "/venue/api/getexportrecordlist", {**common(token, venue_id), "venue_id": venue_id})
    records = data.get("data") or []
    if isinstance(records, dict):
        records = records.get("list") or records.get("data") or []
    return records


def record_matches(record: dict[str, Any], name: str, month: str) -> bool:
    report_type = str(record.get("report_type") or record.get("select_type") or "")
    expected_type = P1_CENTER_NAME_TO_TYPE.get(name)
    if expected_type and report_type == expected_type:
        return True
    text = json.dumps(record, ensure_ascii=False)
    return name in text


def wait_and_download_center(session: requests.Session, token: str, store: str, venue_id: str, name: str, month: str, out_dir: Path, export_date: dt.date, wait_seconds: int) -> dict[str, Any]:
    deadline = time.time() + wait_seconds
    last_status = None
    while True:
        records = center_records(session, token, venue_id)
        for record in records:
            if not record_matches(record, name, month):
                continue
            last_status = record.get("report_status")
            file_url = record.get("report_data_url") or record.get("url") or record.get("download_url")
            if str(last_status) == "1" and file_url:
                start = dt.date.fromisoformat(month + "-01")
                next_month = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
                end = next_month - dt.timedelta(days=1)
                dest = out_dir / f"{store}-{name}-{start:%Y-%m-%d}至{end:%Y-%m-%d}-{export_date:%Y-%m-%d}{safe_ext_from_url(file_url, '.xlsx')}"
                size = download_file(session, file_url, dest)
                return {"store": store, "name": name, "status": last_status, "path": str(dest), "size": size, "url": file_url}
        if time.time() >= deadline:
            return {"store": store, "name": name, "status": last_status or "not_ready", "path": None, "size": 0, "url": None}
        time.sleep(5)


def convert_xls(base_dir: Path) -> list[str]:
    libreoffice = shutil.which("libreoffice")
    converted: list[str] = []
    if not libreoffice:
        return converted
    for xls in base_dir.rglob("*.xls"):
        out_dir = xls.parent / "converted-xlsx"
        out_dir.mkdir(parents=True, exist_ok=True)
        subprocess.run([libreoffice, "--headless", "--convert-to", "xlsx", "--outdir", str(out_dir), str(xls)], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120)
        target = out_dir / (xls.stem + ".xlsx")
        if target.exists():
            converted.append(str(target))
    return converted


def previous_week(today: dt.date) -> tuple[dt.date, dt.date]:
    this_monday = today - dt.timedelta(days=today.weekday())
    start = this_monday - dt.timedelta(days=7)
    return start, start + dt.timedelta(days=6)


def previous_month(today: dt.date) -> tuple[dt.date, dt.date, str]:
    first_this_month = today.replace(day=1)
    end = first_this_month - dt.timedelta(days=1)
    start = end.replace(day=1)
    return start, end, start.strftime("%Y-%m")



def read_table_rows(path: str | None) -> list[dict[str, Any]]:
    try:
        if not path:
            return []
        import pandas as pd
        file_path = Path(path)
        if not file_path.exists() or file_path.is_dir():
            return []
        if file_path.suffix.lower() == ".csv":
            df = pd.read_csv(file_path)
        else:
            df = pd.read_excel(file_path)
        df = df.fillna("")
        return df.to_dict("records")
    except Exception as exc:
        log(f"analysis read failed {path}: {exc}")
        return []


def pick_file(files: list[dict[str, Any]], store: str, name: str) -> str | None:
    for item in files:
        if item.get("store") == store and item.get("name") == name and item.get("path"):
            path = Path(item["path"])
            if path.suffix.lower() == ".xls":
                converted = path.parent / "converted-xlsx" / (path.stem + ".xlsx")
                if converted.exists():
                    return str(converted)
            return str(path)
    return None


def cell(row: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in row:
            return row.get(name)
    for key, value in row.items():
        if any(name in str(key) for name in names):
            return value
    return ""


def to_float(value: Any) -> float:
    try:
        text = str(value).replace(",", "").replace("¥", "").strip()
        return float(text) if text else 0.0
    except Exception:
        return 0.0


def top_counts(rows: list[dict[str, Any]], *field_names: str, limit: int = 5) -> list[tuple[str, int]]:
    counts: dict[str, int] = {}
    for row in rows:
        value = str(cell(row, *field_names)).strip()
        if not value:
            value = "未标记"
        counts[value] = counts.get(value, 0) + 1
    return sorted(counts.items(), key=lambda item: item[1], reverse=True)[:limit]


def analyze_p0(result: dict[str, Any]) -> dict[str, Any]:
    actions: list[str] = []
    store_reports = []
    for store in STORES:
        member_rows = read_table_rows(pick_file(result["files"], store, "会员基础表") or "")
        card_rows = read_table_rows(pick_file(result["files"], store, "会员卡表") or "")
        league_rows = read_table_rows(pick_file(result["files"], store, "团课预约记录") or "")
        private_rows = read_table_rows(pick_file(result["files"], store, "私教预约记录") or "")
        consume_rows = read_table_rows(pick_file(result["files"], store, "刷卡扣费记录") or "")
        change_rows = read_table_rows(pick_file(result["files"], store, "变更记录") or "")
        consultant_top = top_counts(member_rows, "会籍顾问", "顾问", limit=3)
        source_top = top_counts(member_rows, "渠道来源", "来源", limit=3)
        cards_by_status = top_counts(card_rows, "卡状态", "状态", limit=5)
        league_cancel_like = sum(1 for row in league_rows if any(word in str(row) for word in ("取消", "爽约", "未到", "旷课")))
        private_cancel_like = sum(1 for row in private_rows if any(word in str(row) for word in ("取消", "爽约", "未到", "旷课")))
        active_cards = sum(1 for row in card_rows if any(word in str(cell(row, "卡状态", "状态")) for word in ("正常", "使用", "有效")))
        low_balance = sum(1 for row in card_rows if 0 < to_float(cell(row, "余额", "剩余")) <= 5)
        report = {
            "store": store,
            "member_count": len(member_rows),
            "card_count": len(card_rows),
            "active_card_estimate": active_cards,
            "low_balance_estimate": low_balance,
            "league_booking_count": len(league_rows),
            "private_booking_count": len(private_rows),
            "consume_count": len(consume_rows),
            "change_count": len(change_rows),
            "consultant_top": consultant_top,
            "source_top": source_top,
            "card_status_top": cards_by_status,
            "league_exception_estimate": league_cancel_like,
            "private_exception_estimate": private_cancel_like,
        }
        store_reports.append(report)
        if low_balance >= 20:
            actions.append(f"{store} 先筛余额/剩余次数低的会员做续费窗口，至少当天分配20个给所属老师跟进。")
        if len(league_rows) >= 250:
            actions.append(f"{store} 团课预约量高，筛近两周高频团课客户，优先推小班或私教体验。")
        if len(private_rows) < 50:
            actions.append(f"{store} 私教预约偏少，店长要查私教会员本周未预约名单，老师逐个约下次课。")
        if league_cancel_like + private_cancel_like >= 20:
            actions.append(f"{store} 预约异常较多，先做爽约/取消客户复约，别急着拉新。")
    if not actions:
        actions.append("本周先做常规三件事：低余额续费、近14天未到店复约、高频团课客户转小班/私教。")
    return {
        "summary": f"P0 已读取双店会员、会员卡、预约、刷卡、变更数据，周期 {result['start']} 至 {result['end']}。",
        "store_reports": store_reports,
        "owner_actions": actions[:8],
        "boss_message": "\n".join(["南哥，本周 P0 我判断直接抓这几件事：", *[f"{i+1}. {a}" for i, a in enumerate(actions[:5])]]),
    }


def analyze_p1(result: dict[str, Any]) -> dict[str, Any]:
    actions: list[str] = []
    store_reports = []
    all_files = result.get("files", []) + result.get("center_files", [])
    for store in STORES:
        sales_rows = read_table_rows(pick_file(all_files, store, "售卡统计") or "")
        consume_rows = read_table_rows(pick_file(all_files, store, "上课耗卡明细") or "")
        tuition_rows = read_table_rows(pick_file(all_files, store, "课时费统计") or "")
        income_rows = read_table_rows(pick_file(all_files, store, "收入汇总") or "")
        total_sales_amount = sum(to_float(cell(row, "金额", "实收", "收费", "收款")) for row in sales_rows)
        total_consume_amount = sum(to_float(cell(row, "耗卡", "金额", "消耗")) for row in consume_rows)
        sales_by_card = top_counts(sales_rows, "卡名称", "会员卡名称", "卡种", limit=5)
        teacher_top = top_counts(tuition_rows, "老师", "教练", "上课老师", limit=5)
        report = {
            "store": store,
            "sales_rows": len(sales_rows),
            "consume_rows": len(consume_rows),
            "tuition_rows": len(tuition_rows),
            "income_rows": len(income_rows),
            "sales_amount_estimate": round(total_sales_amount, 2),
            "consume_amount_estimate": round(total_consume_amount, 2),
            "sales_by_card_top": sales_by_card,
            "teacher_top": teacher_top,
        }
        store_reports.append(report)
        if len(sales_rows) < 100:
            actions.append(f"{store} 月度成交笔数不高，下月别铺太多活动，主推1个核心卡项加续费窗口。")
        if len(consume_rows) > len(sales_rows) * 3 and len(sales_rows) > 0:
            actions.append(f"{store} 耗卡明显高于售卡，先抓老会员续费和余额承接，别只看现金收入。")
        if sales_by_card:
            actions.append(f"{store} 下月主推卡项先围绕 {sales_by_card[0][0]} 做升级/续费话术，不要重新造太多新卡。")
    not_ready = [f"{x.get('store')} {x.get('name')}" for x in result.get("center_files", []) if not x.get("path")]
    if not_ready:
        actions.append("导出中心未完成项需要下次补抓：" + "、".join(not_ready))
    if not actions:
        actions.append("下月先做三件事：确认主推卡、拆续费名单、按老师看成交与耗卡贡献。")
    return {
        "summary": f"P1 已读取双店月度售卡、耗卡、课时费、收入类数据，月份 {result['month']}。",
        "store_reports": store_reports,
        "owner_actions": actions[:8],
        "boss_message": "\n".join(["南哥，本月 P1 我判断直接抓这几件事：", *[f"{i+1}. {a}" for i, a in enumerate(actions[:5])]]),
    }


def run_p0(args: argparse.Namespace) -> dict[str, Any]:
    today = dt.date.fromisoformat(args.today) if args.today else dt.date.today()
    start = dt.date.fromisoformat(args.start) if args.start else previous_week(today)[0]
    end = dt.date.fromisoformat(args.end) if args.end else previous_week(today)[1]
    export_date = today
    session, token = login()
    results = []
    base_run_dir = RAW
    for store, venue_id in STORES.items():
        out_dir = RAW / store / "每周P0" / end.strftime("%Y-%m-%d")
        for item in P0_ITEMS:
            if args.limit and item[0] not in args.limit:
                continue
            log(f"export P0 {store} {item[0]}")
            results.append(export_direct(session, token, store, venue_id, item, start, end, out_dir, export_date))
    converted = convert_xls(base_run_dir)
    result = {"ok": True, "mode": "p0", "start": str(start), "end": str(end), "export_date": str(export_date), "files": results, "converted": converted}
    result["analysis"] = analyze_p0(result)
    return result


def run_p1(args: argparse.Namespace) -> dict[str, Any]:
    today = dt.date.fromisoformat(args.today) if args.today else dt.date.today()
    start, end, month = previous_month(today)
    if args.month:
        month = args.month
        start = dt.date.fromisoformat(month + "-01")
        next_month = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        end = next_month - dt.timedelta(days=1)
    export_date = today
    session, token = login()
    results = []
    center = []
    for store, venue_id in STORES.items():
        out_dir = RAW / store / "每月P1" / month
        for name, select_type in P1_CENTER_ITEMS:
            if args.limit and name not in args.limit:
                continue
            log(f"submit P1 center {store} {name}")
            submit_center_export(session, token, venue_id, select_type, month)
            center.append(wait_and_download_center(session, token, store, venue_id, name, month, out_dir, export_date, args.wait_center))
        for item in P1_DIRECT_ITEMS:
            if args.limit and item[0] not in args.limit:
                continue
            log(f"export P1 {store} {item[0]}")
            results.append(export_direct(session, token, store, venue_id, (*item, "range"), start, end, out_dir, export_date))
    converted = convert_xls(RAW)
    result = {"ok": True, "mode": "p1", "month": month, "start": str(start), "end": str(end), "export_date": str(export_date), "center_files": center, "files": results, "converted": converted}
    result["analysis"] = analyze_p1(result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["p0", "p1"])
    parser.add_argument("--today")
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--month")
    parser.add_argument("--wait-center", type=int, default=30)
    parser.add_argument("--limit", action="append", help="Only export named item; can repeat")
    args = parser.parse_args()
    try:
        result = run_p0(args) if args.mode == "p0" else run_p1(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        raise


if __name__ == "__main__":
    main()
