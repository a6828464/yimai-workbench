#!/usr/bin/env python3
from __future__ import annotations
import datetime as dt, hashlib, json, os, re, time
from pathlib import Path
from urllib.parse import urlparse
import requests

ENV=Path('${HERMES_PROFILE_DIR}/.env')
for line in ENV.read_text(errors='ignore').splitlines():
    if line and not line.lstrip().startswith('#') and '=' in line:
        k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
BASE='https://cloud.keepyoga.com'; DOWNLOAD='https://importandexport.keepyoga.com'
BRAND='108193'; VERSION='10.1.3'; STORES={'绿地店':'1','东部店':'4250'}
OUT=Path('${YIMAI_BIZ_WIKI}/raw/booking-data/历史预约导出/截至2026-06-30')

def post(s,base,path,body):
    r=s.post(base+path,data=body,timeout=120); r.raise_for_status(); d=r.json()
    if d.get('errno') not in (0,'0',None): raise RuntimeError(f'{path}: {d}')
    return d

def login():
    s=requests.Session(); pwd=hashlib.md5(os.environ['KEEPYOGA_PASSWORD'].encode()).hexdigest()
    d=post(s,BASE,'/passport/api/login',{'phone':os.environ['KEEPYOGA_PHONE'],'pwd':pwd,'keep':1,'brand_id':'','venue_id':''})
    return s,d['data']['access_token']

def chunks(start,end,days=89):
    cur=start
    while cur<=end:
        e=min(cur+dt.timedelta(days=days),end); yield cur,e; cur=e+dt.timedelta(days=1)

def main():
    s,token=login(); result=[]
    for store,venue in STORES.items():
        d=OUT/store; d.mkdir(parents=True,exist_ok=True)
        for start,end in chunks(dt.date(2020,1,1),dt.date(2026,6,30)):
            for kind,path in [('团课预约记录','/course/api/exportqueryreversionleague'),('私教预约记录','/course/api/exportqueryreversionprivate')]:
                dest=d/f'{store}-{kind}-{start:%Y-%m-%d}至{end:%Y-%m-%d}.xls'
                if dest.exists() and dest.stat().st_size>1000:
                    result.append({'store':store,'kind':kind,'start':str(start),'end':str(end),'path':str(dest),'cached':True}); continue
                body={'access_token':token,'brand_id':BRAND,'venue_id':venue,'version':VERSION,'os':'pc','s_date':start.strftime('%Y%m%d'),'e_date':end.strftime('%Y%m%d'),'status_code':'all','course_id':0,'coach_id':0,'m_card_id':0,'search':''}
                if kind.startswith('团'): body['course_type']=0
                data=post(s,DOWNLOAD,path,body); obj=data.get('data') or {}; url=obj.get('url')
                if not url: raise RuntimeError(f'no url {store} {kind} {start} {end}: {data}')
                rr=s.get(url,timeout=120)
                if rr.status_code == 404:
                    # Export host occasionally returns a cloud.keepyoga.com URL whose file is actually served by import/export host.
                    alt=url.replace('https://cloud.keepyoga.com','https://importandexport.keepyoga.com')
                    rr=s.get(alt,timeout=120)
                if rr.status_code == 404:
                    # Empty historical windows may return a nominal URL without creating a file.
                    result.append({'store':store,'kind':kind,'start':str(start),'end':str(end),'count':obj.get('count'),'path':None,'size':0,'empty_or_unavailable':True})
                    continue
                rr.raise_for_status(); dest.write_bytes(rr.content)
                result.append({'store':store,'kind':kind,'start':str(start),'end':str(end),'count':obj.get('count'),'path':str(dest),'size':dest.stat().st_size})
                time.sleep(.15)
    print(json.dumps({'ok':True,'files':len(result),'result':result},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
