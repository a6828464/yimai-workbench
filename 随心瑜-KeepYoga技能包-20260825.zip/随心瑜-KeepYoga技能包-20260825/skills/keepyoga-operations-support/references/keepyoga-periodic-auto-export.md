# KeepYoga P0/P1 自动定时导出实操参考

## 适用场景
南哥要求约课系统 P0/P1 数据不再人工提醒，而是自动登录随心瑜云 / KeepYoga、导出双店数据、落盘归档、再生成简洁结果消息。

## 稳定结论
- 登录站点：`https://cloud.keepyoga.com`
- 下载域：`https://importandexport.keepyoga.com`
- 登录 API：`/passport/api/login`
- 登录字段：`phone` + `pwd`，其中 `pwd` 需要先做 MD5，不是明文密码。
- 品牌 ID：`108193`
- 双店 venue_id：绿地店 `1`，东部店 `4250`
- 凭证不要写进脚本，优先从一麦 profile-local `.env` 或环境变量读取 `KEEPYOGA_PHONE` / `KEEPYOGA_PASSWORD`。

## 已落地脚本
当前一麦 profile 已有脚本：

`${HERMES_PROFILE_DIR}/scripts/keepyoga_periodic_export.py`

可执行：

```bash
python3 scripts/keepyoga_periodic_export.py p0
python3 scripts/keepyoga_periodic_export.py p1
```

调试时可指定日期 / 月份 / 单项：

```bash
python3 scripts/keepyoga_periodic_export.py p0 --today 2026-06-16 --limit 团课预约记录
python3 scripts/keepyoga_periodic_export.py p1 --today 2026-06-16 --month 2026-05 --limit 收入汇总 --wait-center 10
```

## P0 已验证清单
P0 按上周周一至周日导出。双店各导出：

1. 会员基础表：`/member/api/exportmemorvisitor`
2. 会员卡表：`/member/api/exportmm`
3. 团课预约记录：`/course/api/exportqueryreversionleague`
4. 私教预约记录：`/course/api/exportqueryreversionprivate`
5. 刷卡扣费记录：`/course/api/exportpaybycard`
6. 变更记录：`/mcard/api/exportmcardlogs`

验证结果样例：2026-06-08 至 2026-06-14，双店 12 个文件全部成功，并转换归档。

## P1 已验证清单
P1 按上月整月导出。已验证两类链路：

### 即时接口类
- 售卡统计：`/mcard/api/exportmcardstat`
- 上课耗卡明细：`/mcard/api/exportconsumecarddetailstatis`
- 课时费统计：`/course/api/exportcoursesummaryrecordstat`
- 收款统计：`/sale/api/exportreceivablesstatistics`

### 导出中心排队类
- 收入汇总：select_type/report_type `18`
- 耗卡汇总：select_type/report_type `19`
- 资产负债表：select_type/report_type `20`

导出中心提交后通过 `/venue/api/getexportrecordlist` 获取 `report_data_url`。

## 关键坑位
1. **会员基础表和会员卡表不能空传 columns。**
   - `exportmemorvisitor` 和 `exportmm` 要传后台真实导出页生成的完整 columns JSON。
   - 如果传 `[]`，完整 P0 会失败。

2. **导出中心记录名不一定带月份。**
   - 不要只用“文件名包含月份”匹配。
   - 应优先用 `report_type` / `select_type` 匹配：收入汇总 `18`、耗卡汇总 `19`、资产负债表 `20`。

3. **导出中心可能需要等待。**
   - 收入汇总验证中过了几十秒后能拿到文件。
   - 如果首次返回 `not_ready`，不要判断为导出失败，要说明排队未完成或延长等待。

4. **飞书投递失败不等于导出失败。**
   - 历史 P0 cron 曾出现 `Invalid access token`。
   - 处理顺序：先确认脚本导出和文件落盘，再单独排查飞书投递授权。

5. **不要再把 P0/P1 写成提醒任务。**
   - 用户已经确认约课系统信息齐全，可以自动导出。
   - 正确任务形态：脚本自动导出 → agent 根据脚本输出发简洁结果消息。

## Cron 推荐形态
P0：每周一 09:00

```text
script: keepyoga_periodic_export.py p0
prompt: 根据脚本输出说明周期、双店文件和条数、归档路径、失败项；不要提醒人工导出。
```

P1：每月 1 日 09:00

```text
script: keepyoga_periodic_export.py p1
prompt: 根据脚本输出说明月份、双店文件状态、导出中心完成情况、归档路径；不要提醒人工导出。
```

## 输出口径
给南哥只说结果，不展示 token、cookie、手机号、密码、MD5、`.env` 内容。任何凭证相关内容统一写 `[REDACTED]`。

推荐结果结构：

```text
南哥，P0 已自动导完。
周期：YYYY-MM-DD 至 YYYY-MM-DD。
绿地店：会员基础表 X 条、会员卡表 X 条……
东部店：会员基础表 X 条、会员卡表 X 条……
归档：${YIMAI_BIZ_WIKI}/raw/booking-data/定期导出/
失败项：无。
下一步：可基于本周 P0 生成客户经营池/老师看板/周复盘。
```
