# 随心瑜云 P1 月度导出与经营底表生成参考

## 适用场景

用户要求：

- “P1需要的数据也导出一份”
- “做下一步，经营底表”
- “把约课系统导出数据做成经营管理底表”

本参考衔接 `keepyoga-semi-automated-export.md` 的 P0 周度导出流程，用于月度 P1 数据和老板/店长可执行底表。

## 已验证 P1 导出范围

建议月度 P1 先用最近完整月，例如 2026-05-01 至 2026-05-31。

双店各导：

1. 收入汇总，导出中心类，`select_type=18`
2. 耗卡汇总，导出中心类，`select_type=19`
3. 资产负债表，导出中心类，`select_type=20`，可能长时间排队
4. 售卡统计，即时下载，`/mcard/api/exportmcardstat`
5. 上课耗卡明细，即时下载，`/mcard/api/exportconsumecarddetailstatis`
6. 课时费统计，即时下载，`/course/api/exportcoursesummaryrecordstat`
7. 收款统计，即时下载，`/sale/api/exportreceivablesstatistics`，可能返回 0 条

归档目录：

- `raw/booking-data/定期导出/绿地店/每月P1/YYYY-MM/`
- `raw/booking-data/定期导出/东部店/每月P1/YYYY-MM/`

## 关键接口参数

### 收入汇总

```js
fetch(APP.API_PATH + '/venue/api/financialstatementscommonexport', {
  method: 'POST',
  body: APP.objectToFormData({
    export_params: JSON.stringify({
      data_type: 'monthly',
      start_time: '2026-05',
      end_time: '2026-05',
      select_type: 18
    })
  })
})
```

### 耗卡汇总

```js
export_params: JSON.stringify({
  select_type: 19,
  data_type: 'monthly',
  start_time: '2026-05',
  end_time: '2026-05'
})
```

### 资产负债表

```js
export_params: JSON.stringify({
  customer_type: 0,
  sort_type: 1,
  search: '',
  select_type: 20
})
```

### 售卡统计

```js
fetch(APP.API_PATH + '/mcard/api/exportmcardstat', {
  method: 'POST',
  body: APP.objectToFormData({
    type: 1,
    start: '2026-05-01',
    end: '2026-05-31',
    consultant_id: 0,
    flag: 1,
    buy_source: -1,
    is_taste: 2,
    payment_id: 0,
    search: '',
    operator_name: ''
  })
})
```

### 上课耗卡明细

```js
fetch(APP.DOWNLOAD_PATH + '/mcard/api/exportconsumecarddetailstatis', {
  method: 'POST',
  body: APP.objectToFormData({
    start: '2026-05-01',
    end: '2026-05-31',
    card_type: 0,
    card_id: 0,
    card_num: '',
    search: '',
    member_id: 0,
    home_member_id: 0
  })
})
```

### 课时费统计

```js
fetch(APP.API_PATH + '/course/api/exportcoursesummaryrecordstat', {
  method: 'POST',
  body: APP.objectToFormData({
    start: '2026-05-01',
    end: '2026-05-31',
    coach_id: 0,
    course_type: 0,
    page_index: 1,
    page_size: 5000
  })
})
```

### 收款统计

```js
fetch(APP.API_PATH + '/sale/api/exportreceivablesstatistics', {
  method: 'POST',
  body: APP.objectToFormData({
    start_time: '2026-05-01',
    end_time: '2026-05-31',
    consultant_id: 0,
    order_type: 0,
    settlement_status: 0
  })
})
```

## 导出中心文件获取

导出中心列表接口：

```js
fetch(APP.API_PATH + '/venue/api/getexportrecordlist', {
  method: 'POST',
  body: APP.objectToFormData({ venue_id: 1 })
})
```

- 绿地店：`venue_id=1`
- 东部店：`venue_id=4250`
- `report_status=1` 才有 `report_data_url`
- `report_status=0` 是排队生成中，不要卡住整个经营底表

## 数据读取坑

1. 随心瑜云即时导出的 `.xls` 可能浏览器可打开，但 `pandas/xlrd` 读时报 `CompDocError Workbook corruption`。
2. 处理方式：先用 LibreOffice 转为 `.xlsx`，放同级 `converted-xlsx/`。

```bash
find "$BASE" -type f -name '*.xls' | while read -r f; do
  dir="$(dirname "$f")/converted-xlsx"
  mkdir -p "$dir"
  libreoffice --headless --convert-to xlsx --outdir "$dir" "$f"
done
```

3. 会员卡表的 `余额` 字段不是纯金额，常见值是 `0次`、`1次`。做到期/过期风险时，不要用 `pd.to_numeric` 直接判断，否则会把风险客户漏掉。
4. 正确做法：从 `余额` 文本中提取数字，结合 `有效期至` 判断。
5. `有效期至` 可能是 `20250913.0` 这种数字文本，先去掉 `.0`，再按 `%Y%m%d` 解析。
6. 收款统计返回 0 条时，按真实空表保留，不要补假数据。
7. 资产负债表如果长时间排队，先标注“暂用会员卡余额/剩余次数替代”，不要等它阻塞底表。

## 经营底表推荐结构

先做 Excel，不要先做复杂 BI。第一版底表建议 8 个 sheet：

1. `老板月度看板`：双店核心经营指标对比。字段：会员数、会员卡数、售卡记录数、售卡实收、收入汇总、卡项收入、退款、上课人次、耗卡、课时费、课时费/耗卡、耗卡/收入。
2. `本周预约交付`：团课预约、私教预约、刷卡扣费、变更记录、状态统计。
3. `会籍顾问售卡`：按会籍顾问统计售卡张数和实收金额。
4. `老师产能耗卡`：按老师统计耗卡人次、耗卡金额、课时费、课时费/耗卡。
5. `课程耗卡排行`：按课程+老师统计耗卡人次和耗卡金额。
6. `会员卡风险跟进`：剩余次数/余额非0，且已过期或60天内到期。
7. `下一步经营动作`：自动生成老板/店长动作，不只展示数据。
8. `原始字段说明`：每张数据表行数和字段，便于复核。

## 经营判断默认口径

- 这类底表不是财务结账表，是经营推进表。
- 第一优先：可分配、可跟进、可复盘。
- 资产负债表没出来时，不影响先抓：收入/售卡口径差异、会员卡风险、老师产能、课程耗卡。
- 会员卡风险页要能直接给店长分配，后续可继续拆成“店长可执行跟进表”。

## 知识库同步

凡新增底表、说明、导出目录变化，都要同步：

- `index.md`：运营表格区新增文件，统计数字同步增加
- `log.md`：新增一条日期记录，写清数据范围、导出项、底表文件、未完成项
