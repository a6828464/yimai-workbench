# 随心瑜云角色权限审查工作流（端到端可复用版）

## 适用场景
南哥要求"登录约课系统看 XX 角色的权限是否合理"时走审查流程，**不是**新建/编辑角色。

## 铁律（违反一次就会被南哥骂"没思考就动"）

1. **永远先用脚本 + API 审查，不要先开浏览器**。API 数据足够出完整分析；浏览器只在南哥明确要看页面样式时再开。
2. **审查前先想清楚 3 件事再动手**：
   - 角色名和 id 是什么？（已知就直接用，未知先 `getrolelist`）
   - 这角色是给谁用的？（老板/经营总控台 vs 普通员工辅助，决定白名单口径）
   - 输出的"是否合理"判断标准是什么？（白名单包含哪些 + 黑名单包含哪些）
3. **5 次 API 调用以内没拿到全量数据就停下来重规划**。不要再继续探测。

## 端到端工作流（4 步，2 分钟内出报告）

### Step 1：登录拿 token
```python
import hashlib, requests
env = {}  # 读 ${HERMES_PROFILE_DIR}/.env
for line in open(env_path):
    if '=' in line and not line.startswith('#'):
        k, v = line.strip().split('=', 1)
        env[k] = v.strip()
s = requests.Session()
s.headers['User-Agent'] = 'Mozilla/5.0 ...'  # 关键，避免被弹升级页
r = s.post('https://cloud.keepyoga.com/passport/api/login',
           data={'phone': env['KEEPYOGA_PHONE'],
                 'pwd': hashlib.md5(env['KEEPYOGA_PASSWORD'].encode()).hexdigest(),
                 'keep': 1, 'brand_id': '', 'venue_id': ''},
           timeout=30)
token = r.json()['data']['access_token']
```
**坑**：用 `data=` 形参（form 编码），不是 `json=`。`errno=32 信息不完整` 就是 JSON 编码错了。

### Step 2：拉角色清单 + 选目标角色
```python
common = {'access_token': token, 'brand_id': '108193', 'venue_id': '1',
          'version': '10.1.3', 'os': 'pc'}
roles = s.post('https://cloud.keepyoga.com/passport/api/getrolelist',
               data=common).json()['data']['list']
# roles[i] = {id, code, code_desc, name, sys_default, mem_count}
```
一麦当前已知角色：
- 1=超级管理员, 2=老师, 3=店长, 4=前台, 5=会籍顾问, 6=训练规划师
- 25856=财务, **38600=AI助理**

### Step 3：拉角色详情 + 完整菜单树
```python
detail = s.post('https://cloud.keepyoga.com/passport/api/getroledetail',
                data={**common, 'role_id': 38600, 'id': 38600}).json()['data']
menus = s.post('https://cloud.keepyoga.com/passport/api/pcgetmenus',
               data=common).json()['data']
```

**关键发现（2026-07-02 验证）**：
- `auth_node_tree` 只返回 18 个顶级模块的 id 和 name，**子节点 ID 不在里面**
- 翻译 selected_auth_node ID 到中文名必须用 `pcgetmenus`（115 项菜单）做反查
- `getmenuauth` 116 个 key 是"当前登录用户可见的权限动作"，可以反查子节点的具体动作（view/operate/del/edit/export/...），但**只覆盖部分子节点**

### Step 4：翻译 + 分级输出
对 `selected_auth_node` 里每个 ID：
1. 顶级模块：直接用 `auth_node_tree` 的 id→name 映射
2. 菜单子项：递归展平 `pcgetmenus`，建 id→name 字典
3. 真正细粒度操作权限：看 `getmenuauth` 的 key，找到该 ID 对应的动作数组

把每个 ID 翻译成"模块/菜单名 + 可执行动作"两栏：
| 顶级 | 子菜单 | 动作 | 评估 |
|---|---|---|---|

## 已知 ID 翻译速查表（一麦，2026-07-02 验证）

### 顶级模块（18 个，from `auth_node_tree`）
1=场馆管理, 2=课程管理, 3=会员管理, 4=工作台, 6=系统设置, 7=商品管理,
8=营销管理, 10=推送消息提醒, 11=品牌管理, 13=场馆经营诊断, 14=分销商城,
15=学习, 16=小工具, 17=小程序配置, 18=电子合同, 19=数据分析, 20=财务报表, 21=瑜美档案

### AI 助理当前 17 个权限点完整分析（2026-07-02）
| ID | 名称 | 动作 | 评估 |
|---|---|---|---|
| 2 | 课程管理（顶级） | 未明 | ⚠️ 需在页面核实子节点勾选 |
| 3 | 会员管理（顶级） | 未明 | ⚠️ 同上 |
| 4 | 工作台（顶级） | 未明 | ⚠️ 同上 |
| 18 | 电子合同（顶级） | operate, view | 🟡 有 operate 权 |
| 104 | 品牌自定义 | operate | 🔴 缺 view 限制，畸形 |
| 108 | 品牌自定义 | export, view | 🟡 有 export 权 |
| 109 | 视频课程 | add, del, edit, operate, view | 🔴 全权限（增删改） |
| 110 | 品牌自定义 | after_reservation, reservation, view | 🟢 预约类，只读+预约 |
| 111 | 品牌自定义 | operate, view | 🟡 有 operate 权 |
| 175 | 抖音拓客 | view, write_off, write_off_log | 🟡 有核销权 |
| 504/508/516/522/525 | 品牌自定义 | 不在 116-key 权限列表 | ❓ 需页面核实 |
| 635/636 | 品牌自定义 | 不在 116-key 权限列表 | ❓ 需页面核实 |

### 高危节点黑名单（按场景）
- **合同高危写入**：171, 172, 173, 174, 176
- **会员/卡项写入**：509-524, 583
- **预约签到刷卡**：112, 113, 115, 162, 164, 167, 168, 198, 3015
- **系统/角色编辑**：119-122, 530-541, 602, 619, 634, 654
- **品牌/连锁写入**：141, 571, 144, 575, 3006-3008, 576, 577
- **收款账户**：191, 630, 655
- **商品/营销/分销/短信**：126-132, 150, 585-587, 170, 631-633, 14, 152-156, 589-600

## 输出给南哥的判断框架

按"使用对象"分两个口径，**先问南哥这角色是给谁用的**，再给结论：

### 老板/经营总控台版（推荐保留）
- 课程查看、会员查看、预约记录、数据分析、财务报表、品牌侧财务统计
- 操作日志（只读）、经营诊断查看
- **禁止**：员工/会员/卡项的写删、品牌设置、收款账户、合同发起

### 普通员工辅助版（员工问信息用）
- 课程查看、会员查看、卡项查看、预约记录查看、合同列表
- **禁止**：所有写删、所有财务报表、所有品牌设置、所有经营诊断

## 不要做的事

1. **不要在没确认"使用对象"前下"过宽"或"过严"的结论**。同一个 17 个节点对老板是合理的，对员工就过宽。
2. **不要让"未知 ID"（不在 `getmenuauth` 116 key 里）阻塞分析**。把"未知"列出来，标记"需在页面核实"，继续出主报告。
3. **不要试图通过浏览器登录后用 JS 调用 API 拿数据**。`switchVenue.php` 强制要点击选馆，Hermes 这边注入 localStorage 不会触发后续跳转，会被踢回 login.php。脚本走 API 已经能覆盖 100% 审查需求。
4. **不要碰 `/passport/api/getauthnode`、`/getauthnodebyid`、`/getpermissiondetail` 这类"单节点查询"端点**。随心瑜云这套接口不存在或全部返回 500/404，是死路。

## 验证脚本模板

完整可运行的端到端审查脚本：
- `scripts/keepyoga_audit_role.py`（推荐南哥跑这条命令直接出报告）
