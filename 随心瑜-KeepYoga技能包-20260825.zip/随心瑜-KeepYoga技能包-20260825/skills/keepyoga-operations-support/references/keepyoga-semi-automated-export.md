# 随心瑜云半自动导出参考

## 适用场景

一麦需要从随心瑜云后台定期导出双店 P0 经营数据，用于客户经营池、老师看板、课程分析和周复盘。

## 核心结论

- 绿地店 `venue_id=1`，东部店 `venue_id=4250`。
- 直接裸请求导出接口会返回“登录过期”，必须通过后台页面会话带上标准参数。
- 标准参数来自 `APP.objectToFormData()` / `APP.getNormalQuery()`：`access_token`、`brand_id`、`venue_id`、`version`、`os`。
- 服务器生成的导出文件名容易重复，尤其多个 `daochutongji_108193_<venue_id>.xls`，必须“请求一个、立刻下载一个”，不要批量请求后再统一下载。
- 会员、会员卡通常是全量表；预约、扣费、变更记录按周导出时用本周日期范围。

## P0 六张表

每店每周 P0：

1. 会员基础表，全量
2. 会员卡表，全量
3. 团课预约记录，近 7 天或指定周
4. 私教预约记录，近 7 天或指定周
5. 刷卡扣费记录，近 7 天或指定周
6. 变更记录，近 7 天或指定周

## 已验证接口

### 会员基础表

接口：`/member/api/exportmemorvisitor`

关键参数：

- `type=1`
- `activity_code=-1`
- `activity_id=-1`
- `source_id=-1`
- `consultant_id=-1`
- `columns=全字段 JSON`

注意：`activity_code` 不能传空字符串，前端默认是 `-1`，传空会报“信息不完整”。

### 会员卡表

接口：`/member/api/exportmm`

关键参数：

- `activity_code=-1`
- `activity_id=-1`
- `mcard_type=0`
- `card_type=0`
- `card_id=0`
- `card_status=0`
- `columns=全字段 JSON`

### 团课预约记录

接口：`/course/api/exportqueryreversionleague`

关键参数：

- `s_date=YYYYMMDD`
- `e_date=YYYYMMDD`
- `status_code=all`
- `course_type=0`
- `course_id=0`
- `coach_id=0`
- `m_card_id=0`
- `search=''`

### 私教预约记录

接口：`/course/api/exportqueryreversionprivate`

关键参数：

- `s_date=YYYYMMDD`
- `e_date=YYYYMMDD`
- `status_code=all`
- `course_id=0`
- `coach_id=0`
- `m_card_id=0`
- `search=''`

### 刷卡扣费记录

接口：`/course/api/exportpaybycard`

关键参数：

- `s_date=YYYYMMDD`
- `e_date=YYYYMMDD`
- `course_type=0`
- `course_id=0`
- `search=''`

经营判断：该表可能只包含部分手动刷卡/扣费记录，不一定等同全部预约消课，数量异常少时要和预约签到表交叉核对。

### 变更记录

接口：`/mcard/api/exportmcardlogs`

关键参数：

- `begin_time=YYYY-MM-DD`
- `end_time=YYYY-MM-DD`
- `operation_type=0`
- `cond=''`

## 推荐执行顺序

1. 登录 `https://cloud.keepyoga.com/static/login.php`。
2. 选择门店。
3. 确认页面显示当前馆。
4. 进入对应导出页，让前端初始化 `APP`、字段和本地会话。
5. 用 `APP.objectToFormData(body)` 调导出接口。
6. 拿到 `data.url` 后立即下载到知识库归档目录。
7. 再请求下一张表。
8. 单店六张完成后切换另一门店重复。
9. 更新导出登记表、知识库 `index.md` 和 `log.md`。

## 文件命名

建议：

`门店-数据名称-统计起始日至统计截止日-导出日期.xls`

全量表可用：

`门店-数据名称-全量-导出日期.xls`

## 试跑样例口径

2026-06-07 双店 P0 六张完整落盘，统计周期为 2026-06-01 至 2026-06-07，会员基础表和会员卡表为全量：

| 门店 | 会员基础表 | 会员卡表 | 团课预约 | 私教预约 | 刷卡扣费 | 变更记录 |
|---|---:|---:|---:|---:|---:|---:|
| 绿地店 | 1450 | 4594 | 408 | 63 | 6 | 34 |
| 东部店 | 322 | 1956 | 299 | 32 | 13 | 17 |

这些数字只作为接口验证样例，不作为长期经营结论。刷卡扣费记录数量偏少，经营分析主口径优先用预约记录，刷卡扣费用来补耗卡金额和异常核对。