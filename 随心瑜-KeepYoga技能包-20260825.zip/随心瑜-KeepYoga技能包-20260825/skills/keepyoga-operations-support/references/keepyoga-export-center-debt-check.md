# 随心瑜云导出中心复查：资产负债表状态

## 适用场景
用户要求“查一下资产负债表好了没”“看导出中心文件是否生成”“补下载资产负债表”。

## 已验证口径
- 登录后如果直接访问 `/venue/api/getexportrecordlist`，只带 cookie 可能返回 `errno:6 登录过期` 或 `errno:32 信息不完整`。
- 后台真实凭据在浏览器 `localStorage`：
  - `cloud_user.access_token`
  - `cloud_venue.brand_id`
  - `cloud_venue.id` 作为 `venue_id`
- 查询导出中心时 POST `/venue/api/getexportrecordlist`，body 至少带：
  - `access_token`
  - `brand_id`
  - `venue_id`
  - `page_index=1`
  - `page_size=100`
- 资产负债表记录字段：
  - `report_type: "20"`
  - `report_name` 包含 `资产负债表`
  - `report_status_text` 显示状态
  - `report_data_url` 为空时不可下载

## 推荐查询片段
```js
(async()=>{
  const u=JSON.parse(localStorage.getItem('cloud_user')||'{}');
  const v=JSON.parse(localStorage.getItem('cloud_venue')||'{}');
  const params=new URLSearchParams({
    access_token:u.access_token,
    brand_id:v.brand_id,
    venue_id:v.id,
    page_index:'1',
    page_size:'100'
  });
  const res=await fetch('/venue/api/getexportrecordlist',{
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
    body:params,
    credentials:'include'
  });
  const data=await res.json();
  const list=data.data?.list || [];
  return list.filter(x => String(x.report_type)==='20' || JSON.stringify(x).includes('资产负债'))
    .map(x=>({
      id:x.id,
      report_name:x.report_name,
      report_status:x.report_status,
      report_status_text:x.report_status_text,
      url:x.report_data_url,
      created_at:x.created_at
    }));
})()
```

## 双店切换
- 如果当前 `localStorage.cloud_venue.id` 是 `1`，代表绿地店。
- 东部店切换后 `cloud_venue.id` 为 `4250`。
- 稳定方式：打开 `https://cloud.keepyoga.com/static/switchVenue.php?type=switch`，选择对应门店，再运行查询片段。
- 若访问 `switchVenue.php?type=login` 后自动回到当前工作台，改用 `type=switch`；工作台右上角“切换场馆”只是先展开确认菜单，直接点不一定立刻切馆。

## 复查输出规范
- 必须真实登录并按门店分别查询 `/venue/api/getexportrecordlist` 后再回复，不能沿用上次记忆。
- 筛选 `report_type === "20"` 或 `report_name` 包含 `资产负债表`，优先汇报最新任务，也可顺带列出老任务。
- 只有 `report_status === "1"` 且 `report_data_url` 非空，才说“已生成”；要列门店、任务名、下载链接，并尝试下载归档。
- `report_status === "0"` 或 `report_data_url` 为空时，明确说“排队生成中”，列任务 ID、任务名和状态文字。
- 定期导出归档路径按门店放到 `${YIMAI_BIZ_WIKI}/raw/booking-data/定期导出/<门店>/每月P1/<月份>/`，文件名包含门店和资产负债表。

## 经营判断
资产负债表生成可能长时间显示 `排队生成中`。不要因此卡住经营底表、会员风险表和店长跟进表推进。若 `report_data_url` 为空，明确告诉用户仍在排队；等生成后再补下载归档和更新说明。