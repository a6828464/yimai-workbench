---
name: keepyoga-operations-support
description: KeepYoga导出、权限审计与周期经营分析补充资料。
version: 1.0.0
---
# KeepYoga 运营补充技能

本技能补充角色权限审计、导出中心、周期导出、月度底表和经营分析工作流。使用前先阅读主技能 `yimai-keepyoga-readonly`。

- 权限审计：`scripts/keepyoga_audit_role.py`
- 导出与分析：见 `references/`
- 所有账号密码必须通过环境变量提供，不得写入脚本。
