#!/usr/bin/env python3
"""KeepYoga role permission audit tool.

Usage:
    python3 scripts/keepyoga_audit_role.py 38600
    python3 scripts/keepyoga_audit_role.py 38600 --scope owner
    python3 scripts/keepyoga_audit_role.py --list

Audits a role in 一麦 KeepYoga (cloud.keepyoga.com) by:
1. Logging in (MD5 password from .env)
2. Fetching role list and target role detail
3. Translating selected_auth_node IDs to Chinese names via pcgetmenus
4. Resolving per-node action lists from getmenuauth
5. Classifying each node as SAFE / WARN / DANGER based on the scope
6. Emitting a human-readable Markdown report

Scope:
    owner      — 老板/经营总控台版 (read + export on financial/analytics OK)
    employee   — 普通员工辅助版 (read-only on course/member/card/booking/contract)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import requests

PROFILE_DIR = Path("${HERMES_PROFILE_DIR}")
ENV_PATH = PROFILE_DIR / ".env"
BASE_URL = "https://cloud.keepyoga.com"
BRAND_ID = "108193"
DEFAULT_VENUE = "1"
VERSION = "10.1.3"
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# High-risk node IDs that should NEVER appear in employee-scope role
DANGER_IDS = {
    "contract_writes": [171, 172, 173, 174, 176],
    "member_writes": [509, 510, 511, 512, 513, 514, 583],
    "card_writes": [515, 517, 518, 519, 520, 521, 523, 524],
    "booking_actions": [112, 113, 115, 162, 164, 167, 168, 198, 3015],
    "system_role": [119, 120, 121, 122, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 602, 619, 634, 654],
    "brand_writes": [141, 571, 144, 575, 576, 577, 3006, 3007, 3008],
    "receipts": [191, 630, 655],
    "commerce_marketing": [14, 126, 127, 128, 129, 130, 131, 132, 150, 152, 153, 154, 155, 156, 170, 585, 586, 587, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 631, 632, 633],
}

EMPLOYEE_FORBIDDEN_TOP = {19, 20, 11, 13, 6, 14, 7, 8}


def load_env() -> dict[str, str]:
    env: dict[str, str] = {}
    if not ENV_PATH.exists():
        sys.exit(f"ERROR: {ENV_PATH} not found")
    for line in ENV_PATH.read_text().splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip().strip('"').strip("'")
    if "KEEPYOGA_PHONE" not in env or "KEEPYOGA_PASSWORD" not in env:
        sys.exit("ERROR: KEEPYOGA_PHONE or KEEPYOGA_PASSWORD missing in .env")
    return env


def login(session: requests.Session, phone: str, password: str) -> str:
    md5 = hashlib.md5(password.encode()).hexdigest()
    r = session.post(
        f"{BASE_URL}/passport/api/login",
        data={"phone": phone, "pwd": md5, "keep": 1, "brand_id": "", "venue_id": ""},
        timeout=30,
    )
    r.raise_for_status()
    data = r.json()
    if data.get("errno") not in (0, "0"):
        sys.exit(f"login failed: {data}")
    return data["data"]["access_token"]


def post_api(session: requests.Session, path: str, body: dict[str, Any], token: str) -> dict[str, Any]:
    r = session.post(
        BASE_URL + path,
        data={**body, "access_token": token, "brand_id": BRAND_ID,
              "venue_id": DEFAULT_VENUE, "version": VERSION, "os": "pc"},
        timeout=30,
    )
    r.raise_for_status()
    data = r.json()
    if data.get("errno") not in (0, "0"):
        sys.exit(f"{path} failed: {data}")
    return data["data"]


def fetch_role_detail(session: requests.Session, role_id: str, token: str) -> dict[str, Any]:
    return post_api(session, "/passport/api/getroledetail",
                    {"role_id": role_id, "id": role_id}, token)


def fetch_menus(session: requests.Session, token: str) -> list[dict[str, Any]]:
    return post_api(session, "/passport/api/pcgetmenus", {}, token)


def fetch_menuauth(session: requests.Session, token: str) -> dict[str, list[str]]:
    return post_api(session, "/passport/api/getmenuauth", {}, token)


def flatten_menus(menus: list[dict[str, Any]]) -> dict[str, dict[str, str]]:
    flat: dict[str, dict[str, str]] = {}
    def walk(items: list[dict[str, Any]]) -> None:
        for m in items:
            mid = str(m.get("id"))
            flat[mid] = {"name": m.get("name", ""), "path": m.get("path", "")}
            if m.get("sub"):
                walk(m["sub"])
    walk(menus)
    return flat


def classify_node(node_id: str, scope: str) -> tuple[str, str]:
    if not node_id.isdigit():
        return ("UNKNOWN", "non-numeric id")
    nid = int(node_id)
    if scope == "employee":
        if nid in EMPLOYEE_FORBIDDEN_TOP:
            return ("DANGER", f"员工辅助版不允许顶级模块 {nid}（财务/品牌/诊断/系统/分销/商品/营销）")
        for cat, ids in DANGER_IDS.items():
            if nid in ids:
                return ("DANGER", f"命中黑名单 [{cat}]")
        if nid == 18:
            return ("WARN", "电子合同顶级，仅允许只读子节点（合同列表/我发起的/全部）")
        return ("SAFE", "员工版白名单范围")
    for cat, ids in DANGER_IDS.items():
        if nid in ids:
            if cat in {"contract_writes", "receipts", "brand_writes"}:
                return ("DANGER", f"老板版也禁止 [{cat}]")
            return ("WARN", f"高危动作 [{cat}]，需评估")
    return ("SAFE", "老板版可接受")


def render_report(role_detail: dict, menu_flat: dict, menuauth: dict, scope: str) -> str:
    selected = role_detail.get("selected_auth_node", [])
    top_tree = role_detail.get("auth_node_tree", [])
    top_by_id: dict[str, str] = {str(m.get("id")): m.get("name", "") for m in top_tree}

    out: list[str] = []
    out.append(f"# 角色权限审查报告")
    out.append("")
    out.append(f"- 角色名：**{role_detail.get('role_name')}**")
    out.append(f"- 角色 ID：`{role_detail.get('role_id')}`")
    out.append(f"- 角色 code：`{role_detail.get('role_code')}` / {role_detail.get('role_code_desc')}")
    out.append(f"- 备注：{role_detail.get('remark', '')}")
    out.append(f"- 审查口径：**{scope}**")
    out.append(f"- 勾选节点数：{len(selected)}")
    out.append("")
    out.append("| ID | 名称 | 动作 | 评估 | 说明 |")
    out.append("|---|---|---|---|---|")

    severities = {"DANGER": 0, "WARN": 0, "SAFE": 0, "UNKNOWN": 0}
    for nid in selected:
        actions = menuauth.get(nid, [])
        if nid in top_by_id:
            name = f"⭐ {top_by_id[nid]}"
        elif nid in menu_flat:
            entry = menu_flat[nid]
            name = entry["name"] or entry["path"] or "?"
        else:
            name = "❓ 未在菜单中（品牌自定义）"
        sev, reason = classify_node(nid, scope)
        severities[sev] += 1
        action_str = ", ".join(actions) if actions else "（未明，登录态未分配动作）"
        sev_icon = {"DANGER": "🔴", "WARN": "🟡", "SAFE": "🟢", "UNKNOWN": "❓"}[sev]
        out.append(f"| {nid} | {name} | {action_str} | {sev_icon} {sev} | {reason} |")

    out.append("")
    out.append(f"## 统计")
    out.append(f"- 🔴 危险：{severities['DANGER']}")
    out.append(f"- 🟡 警告：{severities['WARN']}")
    out.append(f"- 🟢 安全：{severities['SAFE']}")
    out.append(f"- ❓ 未知：{severities['UNKNOWN']}")
    out.append("")

    if severities["DANGER"] > 0:
        out.append("## 建议立即处理")
        out.append("")
        out.append("- 收回高危权限节点（见上表 🔴 行）")
        out.append("- 调整后用 `preeditrolewithsuper` 回读验证")
        out.append("- 编辑后必须再次跑本脚本确认剩余 0 DANGER")
    return "\n".join(out)


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit a KeepYoga role's permissions")
    parser.add_argument("role_id", nargs="?", help="Role ID to audit (e.g. 38600 for AI助理)")
    parser.add_argument("--scope", choices=["owner", "employee"], default="employee",
                        help="审查口径：owner=老板/经营总控台，employee=普通员工辅助")
    parser.add_argument("--list", action="store_true", help="List all roles then exit")
    parser.add_argument("--json", action="store_true", help="Output raw JSON instead of Markdown")
    args = parser.parse_args()

    env = load_env()
    s = requests.Session()
    s.headers["User-Agent"] = UA

    token = login(s, env["KEEPYOGA_PHONE"], env["KEEPYOGA_PASSWORD"])

    if args.list:
        roles = post_api(s, "/passport/api/getrolelist", {}, token)["list"]
        print("| ID | 名称 | code | 系统预设 | 人数 |")
        print("|---|---|---|---|---|")
        for r in roles:
            print(f"| {r['id']} | {r['name']} | {r.get('code','')} | {r.get('sys_default','')} | {r.get('mem_count','')} |")
        return

    if not args.role_id:
        parser.error("role_id required (or pass --list)")

    detail = fetch_role_detail(s, args.role_id, token)
    menus = fetch_menus(s, token)
    menu_flat = flatten_menus(menus)
    menuauth = fetch_menuauth(s, token)

    if args.json:
        print(json.dumps({
            "role": detail,
            "menu_flat": menu_flat,
            "menuauth": menuauth,
        }, ensure_ascii=False, indent=2))
        return

    print(render_report(detail, menu_flat, menuauth, args.scope))


if __name__ == "__main__":
    main()
