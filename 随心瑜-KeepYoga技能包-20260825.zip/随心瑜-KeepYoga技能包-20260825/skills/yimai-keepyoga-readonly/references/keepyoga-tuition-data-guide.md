# KeepYoga 课时费统计数据处理指南

## 数据来源
P1 月度导出 "课时费统计"，导出脚本 `keepyoga_periodic_export.py p1 --month YYYY-MM --limit 课时费统计`

## 关键坑：列名不统一

**绿地店** 文件列名：`['老师', '课程类型', '课程名称', '上课次数', '课时费金额(总)']`
**东部店** 文件列名：`['教练', '课程类型', '课程名称', '上课次数', '课时费金额(总)']`

东部店用 `教练` 而非 `老师`。合并时必须统一：

```python
import pandas as pd
df = pd.read_excel(path)
if '教练' in df.columns:
    df.rename(columns={'教练': '老师'}, inplace=True)
```

## 跨店老师汇总

有些老师在两店都有排课（钱冰璐、瑞文、琴琴、渃兮、围围、泽兴、一桐等）。计算总课时时必须：

1. 先按 `df.groupby(['老师', '课程类型'])['上课次数'].sum()` 跨店汇总
2. 再按老师总课时排序

如果只按单店分组，跨店老师的课时会被拆散，排名失真。

## 课程类型分类
- 团课
- 私教课
- 精品课

## 典型读取流程

```python
from pathlib import Path
import pandas as pd

base = Path("${YIMAI_BIZ_WIKI}/raw/booking-data/定期导出")

def get_latest_tuition(store, month):
    """取最新版本的课时费统计xlsx（可能有多次导出）"""
    converted = base / store / "每月P1" / month / "converted-xlsx"
    if not converted.exists():
        return None
    files = sorted(converted.glob("*课时费统计*.xlsx"), reverse=True)
    return files[0] if files else None

all_rows = []
for store in ["绿地店", "东部店"]:
    for month in months:
        f = get_latest_tuition(store, month)
        if not f:
            continue
        df = pd.read_excel(f)
        if '教练' in df.columns:
            df.rename(columns={'教练': '老师'}, inplace=True)
        df['门店'] = store
        df['月份'] = month
        all_rows.append(df)

df_all = pd.concat(all_rows, ignore_index=True)
```

## 排名输出
给老板/店长的排名表应包含：老师、团课、私教课、精品课、总计。跨店老师合并计，不拆店。
