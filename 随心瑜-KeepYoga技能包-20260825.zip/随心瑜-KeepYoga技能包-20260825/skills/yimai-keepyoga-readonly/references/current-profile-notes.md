# 当前 profile 脚本状态与迁移注意

## 当前 profile

```text
${HERMES_PROFILE_DIR}
```

当前已确认存在：

```text
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py
${HERMES_PROFILE_DIR}/scripts/keepyoga_periodic_export.py
${HERMES_PROFILE_DIR}/skills/yimai-business/yimai-studio-operations-architect/scripts/keepyoga_audit_role.py
```

实时单会员查询脚本已验证命令：

```bash
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py venues
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py counts
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py member-analyze --venue 绿地店 --query 示例会员
```

2026-07 实测：`counts` 可读双店会员、访客、会员卡数量；示例会员查询命中会员，读取 5 张卡、59 条预约记录，隐私检查未泄露完整手机号、长卡号、token。

原技能包中出现的旧路径不可直接使用：

```text
<OLD_PROFILE_PATH>
<OLD_WIKI_PATH>
```

应替换为：

```text
${HERMES_PROFILE_DIR}
${YIMAI_BIZ_WIKI}
```

## 使用原则

### 周/月经营分析

优先使用现有周期导出脚本：

```bash
${HERMES_PROFILE_DIR}/scripts/keepyoga_periodic_export.py
```

具体按门店运营技能参考执行：

- `yimai-studio-operations-architect/references/keepyoga-periodic-auto-export.md`
- `yimai-studio-operations-architect/references/keepyoga-periodic-analysis-layer.md`
- `yimai-studio-operations-architect/references/keepyoga-p1-monthly-base-table.md`

### 角色权限审查

优先使用：

```bash
python3 ${HERMES_PROFILE_DIR}/skills/yimai-business/yimai-studio-operations-architect/scripts/keepyoga_audit_role.py <role_id> --scope owner
```

南哥本人使用的 AI 助理按 owner scope，不按 employee scope。

### 单会员实时查询

如果未来迁移或重建 `keepyoga_readonly.py`，必须满足：

- 使用当前 profile `.env`，不要读旧 profile。
- 不用 `os.path.expanduser("~")` 推导真实用户家目录，因为 Hermes profile 下 `$HOME` 会被重定向。
- 会员/访客全量查询不要把 `consultant_id=0` 当全部顾问；`0` 通常代表未分配顾问。
- 输出必须脱敏。
- 只读查询可以拉满，写操作仍禁止。

## 老板版权限口径

南哥已确认该智能体只有他使用，所以：

- 数据分析、导出中心、财务经营数据、会员卡、预约、合同、客户档案等可读权限可以拉满。
- 分析可站在老板视角，允许输出门店、老师服务承接、客户经营动作。
- 但不能自动执行删改、收款、退款、发卡、刷卡、签到、取消预约等写动作。
