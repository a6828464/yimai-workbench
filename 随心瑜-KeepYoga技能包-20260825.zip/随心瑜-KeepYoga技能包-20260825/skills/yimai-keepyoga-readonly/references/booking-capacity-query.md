# KeepYoga 预约容量只读查询参考

## 场景

当南哥问某天某店每节课预约多少人、还剩几个名额、有没有排队时，不能只读课表接口。

课表接口只回答“有什么课”；容量接口才回答“约了多少、还能约多少”。

## 推荐流程

1. 先读取目标门店目标日期课表，拿到课程 `schedule_id`。
2. 再调用工作台预加载接口读取当天课程容量。
3. 输出课程层面的聚合数字，不展示会员姓名、手机号、卡号。

## 关键接口

### 课表接口

```text
/course/api/getleaguecourselistbyweek
```

常用 body：

```json
{"week":"0"}
```

关键字段：

- `id`：课程排课 ID，可作为后续 `schedule_id`
- `date`
- `start`
- `end`
- `name`
- `coach`
- `classroom`
- `status_desc`

### 预约容量预加载接口

```text
/course/api/preworkbenchreversionleague
```

常用 body：

```json
{
  "page_index":"1",
  "page_size":"20",
  "search":"",
  "course_type":"0",
  "schedule_id":"<任意当日 schedule_id>",
  "date_str":"YYYY-MM-DD"
}
```

实测口径：传当天任意一个 `schedule_id` + `date_str`，通常会返回当天课程工作台列表。后续按 `start_time` 或 `schedule_id` 筛目标课程。

关键字段位于 `data.course_schedule[]`：

- `schedule_id`
- `start` / `end`
- `course_name`
- `course_type_name`
- `coach_name`
- `classroom`
- `size`：课程容量
- `occupied`：已预约人数
- `reservation_queue_count`：排队人数
- `can_join_queue`：是否可排队
- `is_stop` / `is_cancel`

## 工作台数字定义

课程卡片中教室下方三段数字：

```text
已签到人数 | 已预约人数 | 可预约人数
```

回答时优先使用这个口径：已签到、已预约、可预约。`occupied` 可作为已预约人数参考，排队人数读取 `reservation_queue_count`。

## 输出示例

```text
我看了东部店今天预约情况，晚间更值得盯：

| 时间 | 课程 | 老师 | 类型 | 已约/容量 | 剩余 | 排队 |
|---|---|---|---|---|---|---|
| 14:00-15:00 | 室内蹦极 | 嘉欣 | 精品课 | 6/6 | 0 | 1 |
| 16:00-17:00 | 内观流 | 芷晴 | 团课 | 4/18 | 14 | 0 |

我判断：14:00 这节已经满了，店长只需要盯候补；16:00 还有空间，可以让老师今天补约 3-5 个低活跃会员。
```

## 隐私边界

`/course/api/workbenchreversionleague` 可能返回预约会员明细，含会员姓名、完整手机号、会员卡号、卡有效期等。

如果南哥只问人数/剩余名额，不要展示会员明细。只有南哥明确要“这节课都是谁”时，才输出必要的脱敏名单。
