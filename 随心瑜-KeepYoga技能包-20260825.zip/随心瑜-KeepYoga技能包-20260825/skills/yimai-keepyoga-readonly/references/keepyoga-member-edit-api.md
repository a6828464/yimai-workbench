# KeepYoga 会员资料编辑（API 方式）

## 适用场景

当需要编辑会员资料字段（职业、婚姻、孕产、备注等），且浏览器 UI 操作慢或 session 容易过期时，使用 Python 脚本直接调 API 更可靠。

## 已验证端点

```
POST /member/api/updatemember
```

errno=0 表示成功。所有参数以 POST form-data 方式提交，不是 JSON body。

## 通用参数（必填）

```python
base = {
    'access_token': token,     # 登录获取
    'brand_id': '108193',       # 一麦品牌ID
    'venue_id': '1',            # 绿地店=1, 东部店=4250
    'version': '10.1.3',
    'os': 'pc',
    'member_id': '<MEMBER_ID>',        # 会员ID
    'home_member_id': '0',      # 非家庭成员
}
```

## 已验证可编辑字段

| 字段名 | 类型 | 说明 | 已测试值 |
|---|---|---|---|
| `occupation_type` | 字符串 | 职业类型 | "手术室医生" |
| `marriage` | 字符串 | 婚姻状态编码 | "1"（已婚） |
| `marriage_desc` | 字符串 | 婚姻状态描述 | "已婚" |
| `pregnancy` | 字符串 | 孕产情况 | "第一胎" |
| `job` | 字符串 | 职业 | 未测试 |
| `hobby` | 字符串 | 爱好 | 未测试 |
| `notes` | 字符串 | 备注 | 未测试 |
| `height` | 字符串 | 身高 | 未测试 |
| `education` | 数字 | 学历编码 | 未测试 |
| `income_situation` | 字符串 | 收入情况 | 未测试 |
| `personality_traits` | 字符串 | 性格特征 | 未测试 |
| `notes_behavior` | 字符串 | 行为动态 | 未测试 |
| `address` | 字符串 | 地址 | 未测试 |
| `housing_estate` | 字符串 | 小区名称 | 未测试 |

## 婚姻状态编码

| 值 | 含义 |
|---|---|
| 0 | 未设置/未婚 |
| 1 | 已婚 |

## 完整操作流程（Python）

```python
import hashlib, requests
from pathlib import Path

# 1. 从 .env 读凭证
env = Path('${HERMES_PROFILE_DIR}/.env')
phone = pwd = None
for line in env.read_text().splitlines():
    if 'KEEPYOGA_PHONE' in line:
        phone = line.split('=',1)[1].strip().strip('"\'')
    if 'KEEPYOGA_PASSWORD' in line:
        pwd = line.split('=',1)[1].strip().strip('"\'')

BASE = 'https://cloud.keepyoga.com'
s = requests.Session()
pw = hashlib.md5(pwd.encode('utf-8')).hexdigest()
r = s.post(BASE + '/passport/api/login', data={
    'phone': phone, 'pwd': pw, 'keep': 1, 'brand_id': '', 'venue_id': ''
}, timeout=30)
token = r.json()['data']['access_token']

# 2. 构造通用参数
base_params = {
    'access_token': token,
    'brand_id': '108193',
    'venue_id': '1',       # 绿地店
    'version': '10.1.3',
    'os': 'pc',
}

# 3. 更新会员资料
update_data = {
    **base_params,
    'member_id': '<MEMBER_ID>',
    'home_member_id': '0',
    'occupation_type': '<OCCUPATION>',
    'marriage': '1',
    'marriage_desc': '已婚',
    'pregnancy': '第一胎',
}

r2 = s.post(BASE + '/member/api/updatemember', data=update_data, timeout=15)
print(r2.json())  # {'errno': 0, 'error': 'ok'} 为成功

# 4. 回读验证
detail = s.post(BASE + '/member/api/getmemberdetail', data={
    **base_params, 'member_id': '<MEMBER_ID>', 'home_member_id': '0'
}, timeout=15)
member = detail.json()['data']['member']
print(member.get('occupation_type'))  # 手术室医生
print(member.get('marriage_desc'))    # 已婚
print(member.get('pregnancy'))        # 第一胎
```

## 读取 member 完整字段

`/member/api/getmemberdetail` 返回的 `data.member` 包含所有可编辑字段。需要确认字段名时，先打印全部 keys：

```python
detail = s.post(BASE + '/member/api/getmemberdetail', data={
    **base_params, 'member_id': member_id, 'home_member_id': '0'
}, timeout=15)
for k, v in detail.json()['data']['member'].items():
    print(f"{k}: {v}")
```

## 注意事项

- 浏览器 session 约 10-15 分钟无操作后会过期，跳转到 `login.php?type=forbidden`。API 方式每次重新登录获取 token，不受 session 过期影响。
- 所有字段传字符串即可，系统内部会做类型转换。
- 编辑后务必回读验证，`/member/api/updatemember` 返回 errno=0 不代表所有字段都写入成功。
- 不要编辑 `phone`、`name`、`member_id` 等核心标识字段——这些有专门的修改流程。

## 已实践验证

2026-07-08 验证通过：
- 会员：示例会员（绿地店，ID=<MEMBER_ID>）
- 写入字段：示例非核心资料字段写入
- 回读确认：全部写入成功