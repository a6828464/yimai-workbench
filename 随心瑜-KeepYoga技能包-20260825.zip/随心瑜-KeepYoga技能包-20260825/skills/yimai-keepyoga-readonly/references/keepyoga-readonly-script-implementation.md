# KeepYoga 单会员实时查询脚本实现参考

## 适用场景

当需要在一麦经营 profile 新建、维护或排查 `keepyoga_readonly.py` 这类实时只读查询脚本时，按本参考处理。

目标是优先跑通：登录、门店、双店数量、单会员实时画像。不要一开始就把周期导出、经营底表、飞书投递全部塞进同一个脚本。

## 已验证脚本

```bash
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py
```

已验证命令：

```bash
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py venues
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py counts
${HERMES_PROFILE_DIR}/scripts/keepyoga_readonly.py member-analyze --venue 绿地店 --query 示例会员
```

## 实现要点

### 登录

复用周期导出脚本的登录方式：

- 站点：`https://cloud.keepyoga.com`
- 登录接口：`/passport/api/login`
- 密码：`KEEPYOGA_PASSWORD` 明文读取后做 MD5
- 凭证来源：`${HERMES_PROFILE_DIR}/.env`
- 品牌：`brand_id=108193`
- 门店：绿地店 `1`，东部店 `4250`

不要用 `os.path.expanduser("~")` 找真实用户目录，Hermes profile 下 `$HOME` 会重定向。

### 通用响应解析

随心瑜云不同接口的列表字段不统一，通用 `data_list()` 至少要覆盖：

```text
list, data, rows, items, members, visitors, mcards, contracts, course_schedule, reservations
```

分页总数不只在 `total/count`，会员、访客、会员卡常在：

```text
data.fenye.record_count
```

### 访客接口参数坑

`/member/api/getvisitors` 对 `page` 参数很挑：

- 用字符串 `page='1'`
- 不要只传 `page_index`
- 要补齐筛选字段：`source_id=-1`、`activity_id=-1`、`activity_code=''`、`consultant_id=-1`、`begin_time=''`、`end_time=''`、`revisit_status=''`、`trainer_id=-1`

已验证：这样能读出访客总数。

### 合同接口参数坑

`/venue/api/getallcontractlist` 必须显式传 `contract_status`，否则会报“请选择合同状态”。

可用参数形态：

```text
page_index='1'
page_size='1'
contract_status='0'
contract_name=''
initiator_emp_name=''
venue_signatory_emp_name=''
customer_signatory_search=''
initiator_start_date=''
initiator_end_date=''
```

当前返回合同数为 0 时，不等于脚本失败，先按真实系统返回处理。

### 会员/卡项查询

会员搜索优先级：

1. `/member/api/getmembersbycondwithpager`
2. `/member/api/getvisitors`
3. `/mcard/api/getmcardsbycond` 兜底

会员和访客全量查询用 `consultant_id=-1`，不要用 `0`，`0` 常代表未分配顾问。

拿到 `member_id` 后优先读：

```text
/member/api/getmemberdetail
/mcard/api/getmcardbymemberid
```

### 预约记录接口

预约行为分析优先读数据分析接口：

```text
/course/api/queryreversionleague
/course/api/queryreversionprivate
```

关键点：返回列表字段是 `reservations`，不是 `list`。

已验证示例会员：团课/小班 2 条，私教 57 条，总 59 条。

### 隐私检查

每次脚本改完至少检查：

- 完整手机号：不应出现 `1\d{10}`
- 长卡号/长数字：不应出现裸露 `\b\d{12,}\b`
- token：不应出现 `access_token`、`cloud_token`

## 已验证回归样例

2026-07 实测：

```text
counts:
绿地店：会员 1457，访客 715，会员卡 1708，合同 0
东部店：会员 328，访客 538，会员卡 1036，合同 0

member-analyze --venue 绿地店 --query 示例会员:
命中会员，手机号仅显示尾号
会员卡 5 张
预约记录 59 条
签到 53，取消 6，取消率 10.2%
偏好老师：婷婷 36，苏米 18，泽兴 3，瑞文 1，黄敏 1
偏好时段：下午 23，上午 22，晚上 14
偏好星期：周一 22，周四 15，周三 14
最近上课：2026-06-24
```

## 后续加厚方向

第一版脚本先保持小而稳。下一步可在脚本输出中增加老板版经营判断：P0-P5 分层、今日动作、7 天验收、可发客户话术。