# KeepYoga 老师课时统计分析参考

## 数据来源

- 课时费统计：`每月P1/{year}-{month}/converted-xlsx/*课时费统计*.xlsx`
- 指标：`上课次数` = 实际开课/签到次数
- 预约记录：通过 `/course/api/exportqueryreversionleague`（团课）和 `/exportqueryreversionprivate`（私教）按月导出

## 课程分类规则（南哥确认：精品课=小班）

课时费统计 `课程类型` 仅三类：`团课`、`私教课`、`精品课`。

```python
if 课程类型 == '私教课':
    kind = '私教'
elif 课程类型 == '精品课':
    kind = '小班'
else:
    kind = '团课'
```

⚠️ 不要按课程名称里的"小班"关键字来区分类别——南哥明确说过"精品课就是小班课，你思考多余了"。

## 老师姓名标准化（2026-07 验证）

```python
NAME_MAP = {
    '谭婷婷':'婷婷','张炎':'张青','张芷晴':'芷晴','张情':'芷晴',
    '钱冰璐':'冰璐','周娟':'娟子','专职老师':'专职',
}
```

汇总双店前必须做，否则同名老师拆成多条。

## 文件读取要点

- glob 匹配：`f"{converted_xlsx_dir}/*课时费统计*.xlsx"`，用 f-string 拼接中文路径
- 每月可能有多个导出版本，取最新日期文件：`sorted(files)[-1]`
- 列名统一：绿地店 `老师`，东部店 `教练`；预约文件同理 `老师姓名`/`教练姓名`，读前自适应：
  ```python
  col_t = '老师姓名' if '老师姓名' in df.columns else '教练姓名'
  ```

## 预约记录导出要点

### 导出 API

- 团课预约：`/course/api/exportqueryreversionleague`
- 私教预约：`/course/api/exportqueryreversionprivate`
- 端点 base：`https://importandexport.keepyoga.com`

### 必须传的 header 参数（缺 brand_id/version/os 报 errno 32 信息不完整）

```python
body = {
    "access_token": token, "brand_id": BRAND_ID, "venue_id": venue_id,
    "version": VERSION, "os": "pc",
    "s_date": start.strftime("%Y%m%d"), "e_date": end.strftime("%Y%m%d"),
    "status_code": "all",
}
```

### 状态值

只有 `已签到`、`已取消`（无"已预约"状态）。

### 列名

- 团课预约：`会员姓名`、`联系方式`、`上课时间`、`课程名称`、`老师姓名`、`会籍顾问`、`会员卡名称`、`会员卡卡号`、`状态`
- 私教预约：`会员姓名`、`会员联系方式`、`会员卡名称`、`会员卡号`、`上课时间`、`课程名称`、`老师姓名`、`会籍顾问`、`状态`、`卡类型`、`耗卡金额`
- 东部店用 `教练姓名` 替代 `老师姓名`

### 2026-01-06 全量数据快照

- 双店总课时：5,298（私教 2,954 / 56%，小班 1,584 / 30%，团课 760 / 14%）
- 绿地店：2,586，东部店：2,712，共 38 位老师
- 课时量 TOP5：冰璐 540、黄敏 497、琴琴 449、嘉欣 389、渃兮 380
- 2 月春节低谷 356，3 月高峰 1,084，4-6 月平稳 916-1,040
- 已导出 1-6 月预约记录（团课 + 私教），排课数/开课率/服务人次均可统计

### 2026-07-08 数据验证更新

- 课时费统计：1-6 月全部可用（各月 converted-xlsx 已生成）
- 预约记录导出：通过 API 成功导出两店 1-6 月全部 24 个文件（团课预约 12 个 + 私教预约 12 个），已归档到 `每月P1/{month}/` 目录
- HTML 报告配色已修正：bar-cell 深色背景 → 浅色底纹，彻底解决文字看不清问题
- 飞书 open_id 跨 app 报错 → 用 union_id 兜底发送成功

### 排课数/开课率

排课数 = 当月该老师预约记录总数（含已签到+已取消），开课率 = 已签到/排课，服务人次 = 已签到会员人次（同会员同课去重）。

### 排课表 API 不可用

`/course/api/querycourseschedule`、`/course/api/getcourseschedule`、`/course/api/queryschedule` 均返回 errno 500。排课数必须通过预约记录导出获得。

## HTML 报告生成

报告生成脚本保存在 `/tmp/` 下，不长期保留。

### 数据准备

monthly 数据要按 `老师×月份` 透视（一条记录 = 一个老师一个月的合计，含 month/raw_month 字段），**不要**在 HTML 渲染时再做 groupby，否则渲染侧找不到 month 字段。

### 配色可读性

- **不要用 bar-cell 直接套深色 background-color**：深色背景 + 深色文字 = 完全看不清（一麦 session 实测教训）。
- 推荐方案：用 `td.bar-fill` 浅色半透明底色（如 `#E8EFD9`），文字保持深色 `var(--ink)`。
- 分类表的类别字用类别色（绿/棕/黑），底色保持白，不要加深色背景。
- 效率表的百分比用颜色区分高低（绿≥70%，红<40%，灰=中），但底色保持浅。