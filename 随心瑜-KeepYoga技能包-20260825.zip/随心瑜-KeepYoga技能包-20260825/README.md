# 随心瑜 / KeepYoga 技能包

版本：2026-08-25

## 内容

```text
skills/
├── yimai-keepyoga-readonly/      # 主技能：老板经营查询、会员分析、预约/卡项/合同只读分析
└── keepyoga-operations-support/   # 补充技能：权限审计、导出中心、周期导出和月度分析
scripts/
├── keepyoga_readonly.py
├── keepyoga_periodic_export.py
└── export_keepyoga_historical_bookings.py
```

## 安装

将两个技能目录复制到当前 Hermes profile 的 skills 目录：

```bash
cp -r skills/yimai-keepyoga-readonly "$HERMES_PROFILE_DIR/skills/"
cp -r skills/keepyoga-operations-support "$HERMES_PROFILE_DIR/skills/"
```

将脚本复制到 profile scripts 目录：

```bash
cp scripts/*.py "$HERMES_PROFILE_DIR/scripts/"
```

其中：

- `HERMES_PROFILE_DIR`：当前 Hermes profile 目录。
- `YIMAI_BIZ_WIKI`：一麦经营知识库目录；若在其他环境使用，可改成自己的归档目录。

## 账号配置

技能包不包含随心瑜账号、密码、Cookie、Access Token、完整手机号或个人会员资料。

在当前 profile 的 `.env` 中自行配置：

```env
KEEPYOGA_PHONE=随心瑜登录手机号
KEEPYOGA_PASSWORD=随心瑜登录密码
```

不要把 `.env` 放进技能包或提交到 Git。

## 依赖

```bash
python -m pip install requests openpyxl
```

部分数据转换和表格处理还会使用：

```bash
python -m pip install pandas xlrd
```

系统建议安装 LibreOffice，用于旧版 `.xls` 转换：

```bash
which soffice
```

## 快速验证

```bash
python "$HERMES_PROFILE_DIR/scripts/keepyoga_readonly.py" venues
python "$HERMES_PROFILE_DIR/scripts/keepyoga_readonly.py" counts
python "$HERMES_PROFILE_DIR/scripts/keepyoga_readonly.py" member-analyze --venue 绿地店 --query 示例会员
```

## 权限边界

默认允许：

- 查看会员、访客、会员卡、预约、合同、课程、老师和门店数据。
- 导出经营分析所需表格。
- 生成会员经营分层、店长动作和老板经营判断。
- 按主技能约定记录回访、补全非核心会员资料。

默认禁止：

- 发卡、刷卡、签到、取消预约、改排课、收款、退款。
- 删除或修改会员卡、合同、预约等核心业务数据。
- 新增或删除会员档案。
- 输出完整手机号、完整卡号、密码、Token。

## 移植注意

技能正文中的 `${HERMES_PROFILE_DIR}`、`${YIMAI_BIZ_WIKI}` 是路径占位符。若脚本仍使用固定路径，请按新环境修改对应常量，或将其改为环境变量。

此包已删除缓存文件和个人账号信息，并对个人会员示例、手机号和会员ID做了脱敏。
